import random


def vacuum_world():

    goal_state = {'A': '0',
                  'B': '0',
                  'C': '0'}
    cost = 0

    location_input = input("Enter Location of Vacuum :")
    status_input = input("Enter status of " + location_input+" ")
    goal_state[location_input] = status_input

    char = 'A'
    if location_input == char:
        other = chr(ord(char)+1)
        another = chr(ord(char)+2)
    elif location_input == 'B':
        char = 'B'
        other = chr(ord(char)+1)
        another = chr(ord(char)-1)
    else:
        char = 'C'
        other = chr(ord(char)-2)
        another = chr(ord(char)-1)

    status_input_complement = input(f'Enter status of {other}')
    status_input_other = input(f"Enter status of {another}")

    if location_input == 'A':
        goal_state['B'] = status_input_complement
        goal_state['C'] = status_input_other
    elif location_input == 'B':
        goal_state['C'] = status_input_complement
        goal_state['A'] = status_input_other
    elif location_input == 'C':
        goal_state['A'] = status_input_complement
        goal_state['B'] = status_input_other

    print("Initial Location Condition" + str(goal_state))

    if location_input == 'A':
        # Location A is Dirty.
        print("Vacuum is placed in Location A")
        if status_input == '1':
            print("Location A is Dirty.")
            # suck the dirt  and mark it as clean
            goal_state['A'] = '0'
            cost += 1  # cost for suck
            print("Cost for CLEANING A " + str(cost))
            print("Location A has been Cleaned.")

            if status_input_complement == '1':
                # if B is Dirty
                print("Location B is Dirty.")
                print("Moving right to the Location B. ")
                cost += 1  # cost for moving right
                print("COST for moving RIGHT" + str(cost))
                # suck the dirt and mark it as clean
                goal_state['B'] = '0'
                cost += 1  # cost for suck
                print("COST for SUCK " + str(cost))
                print("Location B has been Cleaned. ")

            elif status_input_other == '1':
                # if B is Dirty
                print("Location C is Dirty.")
                print("Moving right to the Location C. ")
                cost += 1  # cost for moving right
                print("COST for moving RIGHT" + str(cost))
                # suck the dirt and mark it as clean
                goal_state['B'] = '0'
                cost += 1  # cost for suck
                print("COST for SUCK " + str(cost))
                print("Location B has been Cleaned. ")

            else:
                print("No action" + str(cost))
                # suck and mark clean
                print("Location B and C is already clean.")

        if status_input == '0':
            print("Location A is already clean ")

            if status_input_complement == '1':  # if B is Dirty
                print("Location B is Dirty.")
                print("Moving RIGHT to the Location B. ")
                cost += 1  # cost for moving right
                print("COST for moving RIGHT " + str(cost))
                # suck the dirt and mark it as clean
                goal_state['B'] = '0'
                cost += 1  # cost for suck
                print("Cost for SUCK" + str(cost))
                print("Location B has been Cleaned. ")

            elif status_input_other == '1':  # if B is Dirty
                print("Location C is Dirty.")
                print("Moving RIGHT to the Location C. ")
                cost += 1  # cost for moving right
                print("COST for moving RIGHT " + str(cost))
                # suck the dirt and mark it as clean
                goal_state['B'] = '0'
                cost += 1  # cost for suck
                print("Cost for SUCK" + str(cost))
                print("Location B has been Cleaned. ")

            else:
                print("No action " + str(cost))
                print(cost)
                # suck and mark clean
                print("Location B is already clean.")

    elif:
        print("Vacuum is placed in location B")
        # Location B is Dirty.
        if status_input == '1':
            print("Location B is Dirty.")
            # suck the dirt  and mark it as clean
            goal_state['B'] = '0'
            cost += 1  # cost for suck
            print("COST for CLEANING " + str(cost))
            print("Location B has been Cleaned.")

            if status_input_complement == '1':
                # if A is Dirty
                print("Location A is Dirty.")
                print("Moving LEFT to the Location A. ")
                cost += 1  # cost for moving right
                print("COST for moving LEFT" + str(cost))
                # suck the dirt and mark it as clean
                goal_state['A'] = '0'
                cost += 1  # cost for suck
                print("COST for SUCK " + str(cost))
                print("Location A has been Cleaned.")

        else:
            print(cost)
            # suck and mark clean
            print("Location B is already clean.")

            if status_input_complement == '1':  # if A is Dirty
                print("Location A is Dirty.")
                print("Moving LEFT to the Location A. ")
                cost += 1  # cost for moving right
                print("COST for moving LEFT " + str(cost))
                # suck the dirt and mark it as clean
                goal_state['A'] = '0'
                cost += 1  # cost for suck
                print("Cost for SUCK " + str(cost))
                print("Location A has been Cleaned. ")
            else:
                print("No action " + str(cost))
                # suck and mark clean
                print("Location A is already clean.")

    # done cleaning
    print("GOAL STATE: ")
    print(goal_state)
    print("Performance Measurement: " + str(cost))


vacuum_world()
