from collections import defaultdict


def vacuum_Total_cost():

    d = defaultdict(lambda: "Not Present")
    cost = 0

    d['A'] = 0
    d['B'] = 0
    d['C'] = 0

    vacuum_posn = input("Enter the position of Vacuum : ")

    if vacuum_posn == 'A':
        char = 'A'
        two = chr(ord(char)+1)
        three = chr(ord(char)+2)
    elif vacuum_posn == 'B':
        char = 'B'
        two = chr(ord(char)-1)
        three = chr(ord(char)+1)
    elif vacuum_posn == 'C':
        char = 'C'
        two = chr(ord(char)-1)
        three = chr(ord(char)-2)

    status_1 = input("Enter the status of "+vacuum_posn+" : ")
    status_2 = input("Enter the status of {} : ".format(two))
    status_3 = input("Enter the status of {} : ".format(three))

    d[vacuum_posn] = status_1
    d[two] = status_2
    d[three] = status_3

    print("Initial State :"+str(d))

    if vacuum_posn:
        if d[vacuum_posn] == '1':
            print(vacuum_posn+" has been cleaned")
            d[vacuum_posn] = '0'
            cost += 1

            if d[two] == '1':
                d[two] = '0'
                print(two+" has been cleaned.")
                cost += 1
            else:
                print(two+" already clean.")
                d[two] = '0'

            if d[three] == '1':
                d[three] = '0'
                print(three+" has been cleaned.")
                cost += 1
            else:
                print(three+" already clean.")
                d[three] = '0'

    print("Final State : "+str(d))

    if vacuum_posn == "A":
        if d[two] == "1" and d[three] == "1":
            cost += 2
        elif d[two] == "1" and d[three] == "0":
            cost += 1
        else:
            pass

    if vacuum_posn == "B":
        if d[two] == "1" and d[three] == "1":
            cost += 3
        elif (d[two] == "1" and d[three] == "0") or (d[two] == "0" and d[three] == "1"):
            cost += 1
        else:
            pass

    if vacuum_posn == "C":
        if d[two] == "1" and d[three] == "1":
            cost += 2
        elif d[two] == "1" and d[three] == "0":
            cost += 1
        else:
            pass

    print("Cleaning Cost : "+str(cost))


vacuum_Total_cost()
